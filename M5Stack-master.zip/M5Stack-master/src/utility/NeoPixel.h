#ifndef _M5_NEOPIXEL_H_
#define _M5_NEOPIXEL_H_
#include <Arduino.h>
class NeoPixelClass {
    public:
      NeoPixelClass() {
		clearAll();
	  }
	  void sendBit(bool flg) {
		for (uint8_t i = 0; i < 2; ++i) digitalWrite(NEOPIXEL_PIN, HIGH);
		for (uint8_t i = 0; i < 6; ++i) digitalWrite(NEOPIXEL_PIN, flg);
		for (uint8_t i = 0; i < 3; ++i) digitalWrite(NEOPIXEL_PIN, LOW);
	  }

	void send(uint32_t color) { // 24bit GRB
	  for (uint8_t i = 0; i < 24; ++i) {
		sendBit(color & 0x800000);
		color = color << 1;
	  }
	}

	  void setColor(uint32_t color[8]) {
		sendBit(false);
		delay(1);
		for (uint8_t i = 0; i < 8; ++i) {
		  send(color[i]);
		}
	  }
	  void setColor(uint32_t color) {
		sendBit(false);
		delay(1);
		for (uint8_t i = 0; i < 8; ++i) {
		  send(color);
		}
	  }
	  void setColor(uint32_t color1, uint32_t color2, uint32_t color3, uint32_t color4, uint32_t color5, uint32_t color6, uint32_t color7, uint32_t color8) 
	  {
		sendBit(false);
		delay(1);
		
		send(color1);
		send(color2);
		send(color3);
		send(color4);
		send(color5);
		send(color6);
		send(color7);
		send(color8);
	  }
	  void clearAll() {
		sendBit(false);
		delay(1);
		for (uint8_t i = 0; i < 8; ++i) {
			send(0);
		}
	  }


    private:
};
#endif